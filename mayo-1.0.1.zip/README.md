#  mayo

Pronounced "my-oh".  Referring to the Spanish word "mayo" which means "May" in English.

## Description

Mayo is a plugin for managing events with admin approval, public submission, and recurring schedules.

## Installation

1. Clone the repository
2. Run `composer install`
3. Run `npm install`
4. Run `npm run build`
5. Run `npm run dev`

## Usage
<?php
/**
 * Template for displaying mayo event details
 */

 get_header(); ?>

<div id="mayo-details-root">details placeholder</div>

<?php 
wp_enqueue_script('mayo-public');
wp_enqueue_style('mayo-public');

get_footer(); 
?> 